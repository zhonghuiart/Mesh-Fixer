# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Mesh Fixer",
    "author" : "ZHONG HUI", 
    "description" : "Efficiency optimization that saves you from repetitive and tedious model checks.",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "https://github.com/zhonghuiart/Mesh-Fixer", 
    "tracker_url": "", 
    "category" : "Mesh" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
class SNA_PT_mesh_fixer_66BEF(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_mesh_fixer_66BEF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Mesh Fixer'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.label(text='Mesh Fixer', icon_value=_icons['header1.png'].icon_id)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Make Sure You're In Object Mode !!", icon_value=0)
        box_EA5D7 = layout.box()
        box_EA5D7.alert = False
        box_EA5D7.enabled = True
        box_EA5D7.active = True
        box_EA5D7.use_property_split = False
        box_EA5D7.use_property_decorate = False
        box_EA5D7.alignment = 'Expand'.upper()
        box_EA5D7.scale_x = 1.0
        box_EA5D7.scale_y = 1.0
        if not True: box_EA5D7.operator_context = "EXEC_DEFAULT"
        split_B42E5 = box_EA5D7.split(factor=0.5, align=False)
        split_B42E5.alert = False
        split_B42E5.enabled = True
        split_B42E5.active = True
        split_B42E5.use_property_split = False
        split_B42E5.use_property_decorate = False
        split_B42E5.scale_x = 1.0
        split_B42E5.scale_y = 1.0
        split_B42E5.alignment = 'Expand'.upper()
        if not True: split_B42E5.operator_context = "EXEC_DEFAULT"
        split_B42E5.label(text='Apply Modifier', icon_value=110)
        col_4E5FD = split_B42E5.column(heading='', align=False)
        col_4E5FD.alert = False
        col_4E5FD.enabled = True
        col_4E5FD.active = True
        col_4E5FD.use_property_split = False
        col_4E5FD.use_property_decorate = False
        col_4E5FD.scale_x = 1.0
        col_4E5FD.scale_y = 1.0
        col_4E5FD.alignment = 'Expand'.upper()
        col_4E5FD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_4E5FD.operator('sna.applymodifiertoselected_729a0', text='to selected', icon_value=604, emboss=True, depress=False)
        op = col_4E5FD.operator('sna.applymodifiertoall_cd503', text='to all', icon_value=27, emboss=True, depress=False)
        box_92335 = layout.box()
        box_92335.alert = False
        box_92335.enabled = True
        box_92335.active = True
        box_92335.use_property_split = False
        box_92335.use_property_decorate = False
        box_92335.alignment = 'Expand'.upper()
        box_92335.scale_x = 1.0
        box_92335.scale_y = 1.0
        if not True: box_92335.operator_context = "EXEC_DEFAULT"
        split_2803C = box_92335.split(factor=0.5, align=False)
        split_2803C.alert = False
        split_2803C.enabled = True
        split_2803C.active = True
        split_2803C.use_property_split = False
        split_2803C.use_property_decorate = False
        split_2803C.scale_x = 1.0
        split_2803C.scale_y = 1.0
        split_2803C.alignment = 'Expand'.upper()
        if not True: split_2803C.operator_context = "EXEC_DEFAULT"
        split_2803C.label(text='Apply Transform & Origin', icon_value=21)
        col_1DC43 = split_2803C.column(heading='', align=False)
        col_1DC43.alert = False
        col_1DC43.enabled = True
        col_1DC43.active = True
        col_1DC43.use_property_split = False
        col_1DC43.use_property_decorate = False
        col_1DC43.scale_x = 1.0
        col_1DC43.scale_y = 1.0
        col_1DC43.alignment = 'Expand'.upper()
        col_1DC43.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_1DC43.operator('sna.transformselected_dc83a', text='to selected', icon_value=604, emboss=True, depress=False)
        op = col_1DC43.operator('sna.transformall_607dd', text='to all', icon_value=571, emboss=True, depress=False)
        box_762B3 = layout.box()
        box_762B3.alert = False
        box_762B3.enabled = True
        box_762B3.active = True
        box_762B3.use_property_split = False
        box_762B3.use_property_decorate = False
        box_762B3.alignment = 'Expand'.upper()
        box_762B3.scale_x = 1.0
        box_762B3.scale_y = 1.0
        if not True: box_762B3.operator_context = "EXEC_DEFAULT"
        split_D7520 = box_762B3.split(factor=0.5, align=False)
        split_D7520.alert = False
        split_D7520.enabled = True
        split_D7520.active = True
        split_D7520.use_property_split = False
        split_D7520.use_property_decorate = False
        split_D7520.scale_x = 1.0
        split_D7520.scale_y = 1.0
        split_D7520.alignment = 'Expand'.upper()
        if not True: split_D7520.operator_context = "EXEC_DEFAULT"
        split_B819C = split_D7520.split(factor=0.8333333134651184, align=False)
        split_B819C.alert = False
        split_B819C.enabled = True
        split_B819C.active = True
        split_B819C.use_property_split = False
        split_B819C.use_property_decorate = False
        split_B819C.scale_x = 1.0
        split_B819C.scale_y = 1.0
        split_B819C.alignment = 'Expand'.upper()
        if not True: split_B819C.operator_context = "EXEC_DEFAULT"
        split_B819C.label(text='Face Orientation Fix', icon_value=583)
        op = split_B819C.operator('sna.showhide_d8f03', text='', icon_value=13, emboss=True, depress=False)
        col_F21B2 = split_D7520.column(heading='', align=False)
        col_F21B2.alert = False
        col_F21B2.enabled = True
        col_F21B2.active = True
        col_F21B2.use_property_split = False
        col_F21B2.use_property_decorate = False
        col_F21B2.scale_x = 1.0
        col_F21B2.scale_y = 1.0
        col_F21B2.alignment = 'Expand'.upper()
        col_F21B2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_F21B2.operator('sna.flip_normal_54e34', text='flip (selected)', icon_value=604, emboss=True, depress=False)
        op = col_F21B2.operator('sna.recalculate_061d6', text='to all', icon_value=571, emboss=True, depress=False)
        box_7CD02 = layout.box()
        box_7CD02.alert = False
        box_7CD02.enabled = True
        box_7CD02.active = True
        box_7CD02.use_property_split = False
        box_7CD02.use_property_decorate = False
        box_7CD02.alignment = 'Expand'.upper()
        box_7CD02.scale_x = 1.0
        box_7CD02.scale_y = 1.0
        if not True: box_7CD02.operator_context = "EXEC_DEFAULT"
        split_7C59B = box_7CD02.split(factor=0.5, align=False)
        split_7C59B.alert = False
        split_7C59B.enabled = True
        split_7C59B.active = True
        split_7C59B.use_property_split = False
        split_7C59B.use_property_decorate = False
        split_7C59B.scale_x = 1.0
        split_7C59B.scale_y = 1.0
        split_7C59B.alignment = 'Expand'.upper()
        if not True: split_7C59B.operator_context = "EXEC_DEFAULT"
        split_7C59B.label(text='Material ID', icon_value=191)
        col_4F30F = split_7C59B.column(heading='', align=False)
        col_4F30F.alert = False
        col_4F30F.enabled = True
        col_4F30F.active = True
        col_4F30F.use_property_split = False
        col_4F30F.use_property_decorate = False
        col_4F30F.scale_x = 1.0
        col_4F30F.scale_y = 1.0
        col_4F30F.alignment = 'Expand'.upper()
        col_4F30F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_4F30F.prop(bpy.context.scene, 'sna_custom_shadername', text='suffix', icon_value=0, emboss=True)
        op = col_4F30F.operator('sna.op_materialid_f607f', text='to all', icon_value=571, emboss=True, depress=False)
        box_34350 = layout.box()
        box_34350.alert = True
        box_34350.enabled = True
        box_34350.active = True
        box_34350.use_property_split = False
        box_34350.use_property_decorate = False
        box_34350.alignment = 'Expand'.upper()
        box_34350.scale_x = 1.0
        box_34350.scale_y = 2.0
        if not True: box_34350.operator_context = "EXEC_DEFAULT"
        op = box_34350.operator('sna.click_and_run_1e54a', text='RUN', icon_value=57, emboss=True, depress=False)


class SNA_OT_Op_Materialid_F607F(bpy.types.Operator):
    bl_idname = "sna.op_materialid_f607f"
    bl_label = "op_materialid"
    bl_description = "Assign material ID based on object name"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        suffix_input = bpy.context.scene.sna_custom_shadername
        # 获取输入后缀，没有则用默认值 "shader"
        try:
            suffix = suffix_input.strip()
            if not suffix:
                suffix = "shader"
        except:
            suffix = "shader"
        # 避免在编辑模式运行材质槽修改
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
        # 使用更稳定的对象获取方式
        for obj in bpy.data.objects:
            if obj.type != 'MESH':
                continue
            mesh = obj.data
            slot_count = len(mesh.materials)
            if slot_count == 0:
                mat_name = f"{obj.name}_{suffix}_1"
                mat = bpy.data.materials.new(name=mat_name)
                mat.use_nodes = True
                mesh.materials.append(mat)
                continue
            for i in range(slot_count):
                mat_name = f"{obj.name}_{suffix}_{i+1}"
                if mat_name not in bpy.data.materials:
                    new_mat = bpy.data.materials.new(name=mat_name)
                    new_mat.use_nodes = True
                else:
                    new_mat = bpy.data.materials[mat_name]
                mesh.materials[i] = new_mat
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Showhide_D8F03(bpy.types.Operator):
    bl_idname = "sna.showhide_d8f03"
    bl_label = "show/hide"
    bl_description = "Toggle display of face orientation in the viewport"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.overlay.show_face_orientation ^= True
                break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Flip_Normal_54E34(bpy.types.Operator):
    bl_idname = "sna.flip_normal_54e34"
    bl_label = "flip normal"
    bl_description = "Flip face normals of selected objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.flip_normals()
                bpy.ops.object.mode_set(mode='OBJECT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Recalculate_061D6(bpy.types.Operator):
    bl_idname = "sna.recalculate_061d6"
    bl_label = "recalculate"
    bl_description = "Recalculate normals outside for all"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)
                bpy.ops.object.mode_set(mode='OBJECT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transformselected_Dc83A(bpy.types.Operator):
    bl_idname = "sna.transformselected_dc83a"
    bl_label = "transformselected"
    bl_description = "Apply transform and center origin (selected only)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transformall_607Dd(bpy.types.Operator):
    bl_idname = "sna.transformall_607dd"
    bl_label = "transformAll"
    bl_description = "Apply transform and center origin (all meshes)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        from mathutils import Matrix
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                # 应用变换：位置、旋转、缩放
                mesh = obj.data
                obj.data = mesh.copy()
                obj.data.transform(obj.matrix_world)
                obj.matrix_world = Matrix.Identity(4)
                # 设置原点为几何中心
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Applymodifiertoselected_729A0(bpy.types.Operator):
    bl_idname = "sna.applymodifiertoselected_729a0"
    bl_label = "applyModifierToSelected"
    bl_description = "Apply all modifiers on selected"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                for mod in obj.modifiers:
                    try:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    except:
                        print(f"Failed to apply modifier '{mod.name}' on {obj.name}")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Applymodifiertoall_Cd503(bpy.types.Operator):
    bl_idname = "sna.applymodifiertoall_cd503"
    bl_label = "applyModifierToAll"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and obj.modifiers:
                bpy.context.view_layer.objects.active = obj
                for mod in obj.modifiers:
                    try:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    except:
                        print(f"Failed to apply modifier '{mod.name}' on {obj.name}")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Click_And_Run_1E54A(bpy.types.Operator):
    bl_idname = "sna.click_and_run_1e54a"
    bl_label = "click and run"
    bl_description = "Click and run"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        from mathutils import Matrix
        # 设置材质命名前缀
        suffix = "shader"
        # 强制切换到 Object 模式（避免某些操作失败）
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
        # 取消全部选择（以防干扰）
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.type != 'MESH':
                continue
            # 设为活动对象
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            # ——— 第一步：应用所有修改器 ———
            for mod in obj.modifiers:
                try:
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                except:
                    print(f"[!] Failed to apply modifier: {mod.name} on {obj.name}")
            # ——— 第二步：应用变换并设置原点为几何中心 ———
            obj.data = obj.data.copy()  # 防止共享 mesh 被破坏
            obj.data.transform(obj.matrix_world)
            obj.matrix_world = Matrix.Identity(4)
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            # ——— 第三步：重计算法线朝外 ———
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent(inside=False)
            bpy.ops.object.mode_set(mode='OBJECT')
            # ——— 第四步：根据命名创建材质并赋值 ———
            mat_slots = obj.data.materials
            slot_count = len(mat_slots)
            if slot_count == 0:
                obj.data.materials.append(None)
                slot_count = 1
            for i in range(slot_count):
                mat_name = f"{obj.name}_{suffix}_{i+1}"
                if mat_name not in bpy.data.materials:
                    new_mat = bpy.data.materials.new(name=mat_name)
                    new_mat.use_nodes = True
                else:
                    new_mat = bpy.data.materials[mat_name]
                obj.data.materials[i] = new_mat
            # 清除选择状态，继续下一个
            obj.select_set(False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_custom_shadername = bpy.props.StringProperty(name='custom_shadername', description='', default='shader', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_PT_mesh_fixer_66BEF)
    if not 'header1.png' in _icons: _icons.load('header1.png', os.path.join(os.path.dirname(__file__), 'icons', 'header1.png'), "IMAGE")
    bpy.utils.register_class(SNA_OT_Op_Materialid_F607F)
    bpy.utils.register_class(SNA_OT_Showhide_D8F03)
    bpy.utils.register_class(SNA_OT_Flip_Normal_54E34)
    bpy.utils.register_class(SNA_OT_Recalculate_061D6)
    bpy.utils.register_class(SNA_OT_Transformselected_Dc83A)
    bpy.utils.register_class(SNA_OT_Transformall_607Dd)
    bpy.utils.register_class(SNA_OT_Applymodifiertoselected_729A0)
    bpy.utils.register_class(SNA_OT_Applymodifiertoall_Cd503)
    bpy.utils.register_class(SNA_OT_Click_And_Run_1E54A)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_custom_shadername
    bpy.utils.unregister_class(SNA_PT_mesh_fixer_66BEF)
    bpy.utils.unregister_class(SNA_OT_Op_Materialid_F607F)
    bpy.utils.unregister_class(SNA_OT_Showhide_D8F03)
    bpy.utils.unregister_class(SNA_OT_Flip_Normal_54E34)
    bpy.utils.unregister_class(SNA_OT_Recalculate_061D6)
    bpy.utils.unregister_class(SNA_OT_Transformselected_Dc83A)
    bpy.utils.unregister_class(SNA_OT_Transformall_607Dd)
    bpy.utils.unregister_class(SNA_OT_Applymodifiertoselected_729A0)
    bpy.utils.unregister_class(SNA_OT_Applymodifiertoall_Cd503)
    bpy.utils.unregister_class(SNA_OT_Click_And_Run_1E54A)
